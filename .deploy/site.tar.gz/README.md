# 초록한칸 — Greenroom Guide

작은 공간에서 시작하는 실내 식물과 생활 가드닝 안내 사이트입니다.

## GitHub Pages 배포
1. GitHub 계정 `eentost`에서 새 공개 저장소 `greenroom-guide`를 만듭니다.
2. 이 ZIP의 **내용물**을 저장소 루트에 업로드합니다. ZIP 파일 자체를 루트에 올리지 마세요.
3. 저장소 Settings → Pages에서 `Deploy from a branch`, `master`(또는 기본 브랜치), `/ (root)`를 선택합니다.
4. 배포 주소: https://eentost.github.io/greenroom-guide/

## 포함된 구성
- 홈, 사이트 소개, 편집·검증 원칙, 참고 자료, 문의, 개인정보처리방침, 이용 안내
- 실내 식물과 베란다 가드닝 가이드 13편
- 모바일 반응형 CSS, 검색 필터, 물 주기 점검 도구 링크
- robots.txt, sitemap.xml, ads.txt
- AdSense 게시자 코드 스니펫: ca-pub-5703399779433493

## AdSense 관련 주의
이 저장소는 승인 가능성을 보장하지 않습니다. Google의 사이트 검토와 정책 준수 여부는 Google이 결정합니다.
광고 로더 코드는 연결용으로 포함되어 있으며 광고 단위는 삽입하지 않았습니다. 사이트 등록 후 AdSense에서 사이트 소유권 및 검토 상태를 확인하세요.
게시자 정보는 기존 계정에 표시된 ID를 사용했습니다. 배포 전 계정의 게시자 ID와 일치하는지 확인하세요.

## 콘텐츠 편집 원칙
- 실제 재배 테스트나 전문 자격을 허위로 주장하지 않습니다.
- 대학 익스텐션 등 공개 자료를 참고하고 원문 링크를 제공합니다.
- 현장 사진·관찰 자료가 추가되면 날짜와 조건을 표시합니다.
- AI 보조 사용 시 사실 확인과 사람의 편집 검토를 거칩니다.

## 변경 전 확인
- `sitemap.xml`과 canonical URL은 저장소 이름 `greenroom-guide` 기준입니다.
- 다른 저장소 이름을 사용하면 canonical, sitemap, 내부 링크를 함께 수정해야 합니다.
